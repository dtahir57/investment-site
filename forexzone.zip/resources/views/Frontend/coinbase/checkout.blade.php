@extends('layouts.front_end')

@section('title','Investment Site')

@section('content')

@endsection