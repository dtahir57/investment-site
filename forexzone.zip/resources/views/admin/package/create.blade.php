@extends('layouts.admin_app')
@section('title', 'Packages')
@section('content')

<h4>Create Packages</h4>
@endsection